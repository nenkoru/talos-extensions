# Registries

The documentation for this topic has been moved to the following articles in [Microsoft Learn](https://learn.microsoft.com/vcpkg):

* [Using registries](https://learn.microsoft.com/vcpkg/users/registries)
* [Creating registries](https://learn.microsoft.com/vcpkg/maintainers/registries)
